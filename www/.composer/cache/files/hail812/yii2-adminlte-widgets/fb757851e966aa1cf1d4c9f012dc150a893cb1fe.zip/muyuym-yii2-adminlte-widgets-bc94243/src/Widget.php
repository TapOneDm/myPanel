<?php

namespace hail812\adminlte\widgets;

class Widget extends \yii\bootstrap4\Widget
{
    use WidgetTrait;
}
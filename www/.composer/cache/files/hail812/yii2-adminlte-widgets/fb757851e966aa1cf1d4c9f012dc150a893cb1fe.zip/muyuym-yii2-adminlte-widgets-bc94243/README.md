yii2-adminlte-widgets
=====================
yii2 adminlte widgets

Installation
------------

The preferred way to install this extension is through [composer](http://getcomposer.org/download/).

v1 for adminlte3

Either run

```
composer require --prefer-dist "hail812/yii2-adminlte-widgets=~1.0"
```

or add

```
"hail812/yii2-adminlte-widgets": "~1.0"
```

to the require section of your `composer.json` file.


Usage
-----

Once the extension is installed, simply use it in your code by  :

```php
<?= \hail812\adminlte\widgets\Alert::widget(); ?>
```
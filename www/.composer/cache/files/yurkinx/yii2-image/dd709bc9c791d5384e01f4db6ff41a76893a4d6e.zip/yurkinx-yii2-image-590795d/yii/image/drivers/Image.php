<?php
namespace yii\image\drivers;

use yii\image\drivers\Kohana_Image;

abstract class Image extends Kohana_Image {}
?>
<?php

declare(strict_types=1);

namespace Codeception\Exception;

use Exception;

class ParseException extends Exception
{
}
